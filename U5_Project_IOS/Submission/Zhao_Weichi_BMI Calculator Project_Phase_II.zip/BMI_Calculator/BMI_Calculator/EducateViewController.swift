//
//  EducateViewController.swift
//  BMI_Calculator
//
//  Created by Weichi Zhao on 6/16/20.
//  Copyright © 2020 Weichi Zhao. All rights reserved.
//

import Foundation
import UIKit
import WebKit

class EducateViewController:UIViewController, WKUIDelegate {
    var newView: WKWebView!
    var passed_url_array = [String]()

    override func viewDidLoad(){
        super.viewDidLoad()
        
        if(passed_url_array.count > 0){
            //assign a randon url in url array for displaying
            let url = URL(string: passed_url_array[Int.random(in: 0..<3)])
            let page = URLRequest (url: url!)
            newView.load(page)
        } else{
            let alert = UIAlertController(title: "Error", message: "No Result for shown,  Please go back!", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    override func loadView() {
        newView = WKWebView(frame: .zero, configuration: WKWebViewConfiguration())
        view = newView
    }
}
